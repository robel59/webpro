fetch('data.json').then(response => response.json()).then(
    data=>{
      var dat = data
    var table ={
        "data":["title1","a1","a2","a3","a4","a5","a6","a7","name1",
                "h2","h3","h5","h7","h9","h11","h12",
                "p1","p3","p5","p7",
                "img1","img2","img4","img6","img7",
                "li8","li9",
                "button2"],
        "table":["table1","table3","table4"],
        "table1":{
            "main":"div1",
            "item":{"child":[
                ["div",["class"],{"class":"col-lg-6"},"div1"],
                ["div",["class","data-wow-duration","data-wow-delay"],{"class":"item wow fadeIn","data-wow-duration":"1s", "data-wow-delay":"0.5s"},"div2"],
                ["div",["class"],{"class":"icon"},"div3"],
                ["div",["class"],{"class":"right-text"},"div4"],
                ["img",["src","alt"],{"src":"assets/images/service-icon-01.png","alt":"reporting"},"img3"],
                ["h4",[],{},"h4"],
                ["p",[],{},"p"]
                ],
                "step":["div4","div3","div2","div1"],
                "loca":{"div4":["h4","p"],"div3":["img3"],"div2":["div3","div4"],"div1":["div2"]}
            }
        },
        "table3":{
            "main":"div9",
            "item":{"child":[
                ["div",["class"],{"class":"col-lg-3 col-sm-6"},"div9"],
                ["div",["class","data-wow-duration","data-wow-delay"],{"class":"item wow bounceInUp","data-wow-duration":"1s", "data-wow-delay":"0.3s"},"div10"],
                ["div",["class"],{"class":"hidden-content"},"div11"],
                ["h4",[],{},"h8"],
                ["p",[],{},"p"],
                ["div",["class"],{"class":"showed-content"},"div12"],
                ["img",["src","alt"],{"src":"assets/images/portfolio-image.png","alt":""},"img5"]
                ],
                "step":["div12","div11","div10","div9"],
                "loca":{"div12":["img5"],"div11":["h8","p"],"div10":["div12","div11"],"div9":["div10"]}
            }
        },
        "table4":{
            "main":"li11",
            "item":{"child":[
                ["li",["class"],{"class":"col-lg-3 col-sm-6"},"li11"],
                ["div",["class"],{"class":"left-content align-self-center"},"div13"],
                ["i",["class"],{"class":"fa fa-calendar"},"i"],
                ["span",[],{},"span3"],
                ["h4",[],{},"h4"],
                ["p",[],{},"p"],
                ["div",["class"],{"class":"right-image"},"div14"],
                ["img",["src","alt"],{"src":"assets/images/blog-thumb-01.jpg","alt":""},"img8"]
                ],
                "step":["span3","div14","div13","li11"],
                "loca":{"span3":["i"],"div14":["img8"],"div13":["span3","h4","p"],"li11":["div13","div14"]}
            }
        }
        }


    table['data'].forEach((i)=>{
        let id = document.getElementById(i)
        if(i.charAt(0) == 'a'){
            var opi = dat[i]
            id.href =opi['link']
            if(opi['text']){
                var ptext = document.createTextNode(opi['text'])
                id.appendChild(ptext)
            }
            if(opi['title']){
                var ptext = document.createTextNode('p')
                id.setAttribute("title", opi['title'])
            }
        }else if(i.charAt(0) == 'v'){
            var opi = dat[i]
            id.src =opi['link']
            if(opi['text']){
                var ptext = document.createTextNode(opi['text'])
                id.appendChild(ptext)
            }
            if(opi['title']){
                var ptext = document.createTextNode('p')
                id.setAttribute("title", opi['title'])
            }
        }else if(i.charAt(0) == 'i' && i.charAt(1) == 'm'){
            id.src = dat[i]['text']
        }else{
            id.innerHTML = dat[i]['text']
        }
    })


    table['table'].forEach((ii)=>{
        let id = document.getElementById(ii)
        var teb = dat["table_data"][ii]
        var dar = table[ii]["item"]

        teb['data'].forEach((data2)=>{
            var op ={}
            dar['child'].forEach((ff)=>{
                var newdiv3 = document.createElement(ff[0])

                if(ff[0] == "a"){
                    newdiv3.href =data2['link']
                    if(data2['titlea']){
                        newdiv3.setAttribute("title", data2['titlea'])
                    }
                }
                if(ff[0] == "i"){
                    newdiv3.setAttribute("class", data2['icon'])
                }
                if(ff[0] == "img"){
                    newdiv3.src =data2['img']['text']
                }else{
                ff[1].forEach((fo)=>{
                    newdiv3.setAttribute(fo, ff[2][fo])
                })
                }
                op[ff[3]]=newdiv3
            })
            dar['step'].forEach((ff)=>{
                dar['loca'][ff].forEach((fo)=>{
                    if(fo !="icon" && fo != "img"){
                        if(data2[fo]){
                            var ptext = document.createTextNode(data2[fo]['text'])
                            op[fo].appendChild(ptext)
                        }
                    }
                    op[ff].appendChild(op[fo])
                })
            })

            id.appendChild(op[table[ii]["main"]])
        })


})
    })
